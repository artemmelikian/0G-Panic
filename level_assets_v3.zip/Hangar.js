const VIEW_ANGLE = Phaser.Math.DegToRad(90); // ширина конуса обзора
const VIEW_RANGE = 90;                        // дальность взаимодействия, px

const MAX_SPEED = 280;   // максимальная скорость, px/с
const ACCEL     = 1100;  // разгон и «сцепление» при смене направления, px/с²
const FRICTION  = 700;   // торможение без ввода (моментум), px/с²
const TURN_SPEED = Phaser.Math.DegToRad(540); // скорость поворота, рад/с

const PLAYER_RADIUS = 20; // радиус героя, px
const HOLD_DIST = PLAYER_RADIUS + 12; // как далеко перед лицом герой держит предмет, px
const ITEM_RADIUS = 17; // радиус столкновения предмета в руках, px
const ITEM_MASS = 0.25;       // масса лежащего предмета относительно героя (меньше — легче толкать)
const ITEM_FRICTION = 900;    // как быстро толкнутый предмет останавливается, px/с²
const IDLE_MASS = 1.5;     // насколько стоящий герой «тяжелее» идущего (больше — труднее сдвинуть)

const KC =Phaser.Input.Keyboard.KeyCodes;

// ── Модели героев ───────────────────────────────────────────────────────
// Спрайт-листы отрендерены из assets/crew/*.glb (Astronaut Crew) под нашу камеру:
// 32 строки — направления (0 = вправо, по часовой).
// 34 колонки: 16 кадров Walk + 1 кадр покоя, затем то же самое «с предметом в руках»
// (руки вытянуты вперёд). В кадрах с предметом на месте куба «вырез»: сам куб рисует игра
// позади спрайта, поэтому руки перед кубом лежат поверх него, а тело за кубом скрыто.
// Покой «дышит» программно (лёгкое покачивание), чтобы не было рваной покадровой анимации.
const SPRITE = {
  frame: 96,                 // ширина кадра, px
  frameH: 112,               // высота кадра, px
  dirs: 32, walk: 16, idle: 1,
  footX: 48, footY: 82,      // где в кадре точка между ступнями
  pxPerUnit: 24,             // пикселей кадра на единицу модели
  walkTime: 0.6,             // длина цикла Walk, с
};
const MODEL_UNIT = 25;       // мировых px на единицу модели (модель ≈ 2.6 ед. ростом)

// ── Уровень ─────────────────────────────────────────────────────────────
// Всё задаётся в клетках сетки 30×15 (клетка TILE px), можно с шагом 0.5.
const TILE = 40;
const GRID_W = 30, GRID_H = 15;
const OX = 40, OY = 80;      // где на экране начинается сетка
const WALL = 14;             // толщина стены, px
const tx = (t) => OX + t * TILE;
const ty = (t) => OY + t * TILE;

// ── Камера ──────────────────────────────────────────────────────────────
// Логика и физика работают на плоском виде сверху (мировые координаты x, y; z — высота).
// На экран всё проецируется настоящей перспективой: камера стоит «к югу» от комнаты,
// наклонена на CAMERA_TILT от вертикали и находится на расстоянии CAMERA_DIST от центра карты.
// Дальняя (верхняя) часть комнаты получается уже ближней — форма /‾\.
const CAMERA_TILT = Phaser.Math.DegToRad(30); // 0 — строго сверху, 15–30 — «условный объём»
const CAMERA_DIST = 1500;    // меньше — сильнее перспектива, больше — почти без неё
const SCREEN_BOX = { l: 20, t: 50, r: 1260, b: 712 }; // куда вписать карту на экране

// Высоты, px
const WALL_H = 60;           // стены
const FRONT_WALL_H = 14;     // нижняя (ближняя к камере) стена — низкая, чтобы не закрывать героев
const LOW_H = 36;            // низкие препятствия (столы/станции)
const HIGH_H = 70;           // высокие препятствия
const PLAYER_H = 40;         // рост героя
const ITEM_SIZE = 28;        // ребро куба-предмета
const HOLD_Z = 12;           // на какой высоте герой держит предмет

// Камера в мировых координатах
const PITCH = Math.PI / 2 - CAMERA_TILT;     // наклон взгляда от горизонта
const CAM_TX = OX + (GRID_W * TILE) / 2, CAM_TY = OY + (GRID_H * TILE) / 2; // куда смотрит
const CAM_Y = CAM_TY + Math.cos(PITCH) * CAMERA_DIST;
const CAM_Z = Math.sin(PITCH) * CAMERA_DIST;

// Сырая перспективная проекция (без масштаба экрана)
const rawProj = (x, y, z) => {
  const ry = y - CAM_Y, rz = z - CAM_Z;
  const depth = -ry * Math.cos(PITCH) - rz * Math.sin(PITCH);
  const up = -ry * Math.sin(PITCH) + rz * Math.cos(PITCH);
  return { u: (x - CAM_TX) / depth, v: -up / depth };
};

// Подгоняем масштаб так, чтобы вся комната со стенами влезла в SCREEN_BOX
const FIT = (() => {
  const pts = [];
  for (const [gx, gy] of [[0, 0], [GRID_W, 0], [0, GRID_H], [GRID_W, GRID_H]])
    for (const z of [0, WALL_H]) pts.push(rawProj(OX + gx * TILE, OY + gy * TILE, z));
  const us = pts.map((p) => p.u), vs = pts.map((p) => p.v);
  const u0 = Math.min(...us), u1 = Math.max(...us), v0 = Math.min(...vs), v1 = Math.max(...vs);
  const k = Math.min((SCREEN_BOX.r - SCREEN_BOX.l) / (u1 - u0), (SCREEN_BOX.b - SCREEN_BOX.t) / (v1 - v0));
  return {
    k,
    ox: (SCREEN_BOX.l + SCREEN_BOX.r) / 2 - k * (u0 + u1) / 2,
    oy: (SCREEN_BOX.t + SCREEN_BOX.b) / 2 - k * (v0 + v1) / 2,
  };
})();

// Мировая точка (x, y) на высоте z → экран
const proj = (x, y, z = 0) => {
  const r = rawProj(x, y, z);
  return { x: FIT.ox + r.u * FIT.k, y: FIT.oy + r.v * FIT.k };
};
window.__proj = proj; // для отладочных скриптов

// Площадь многоугольника на экране: > 0 — грань смотрит на камеру
const screenArea = (pts) => {
  let a = 0;
  for (let i = 0; i < pts.length; i++) {
    const p = pts[i], q = pts[(i + 1) % pts.length];
    a += p.x * q.y - q.x * p.y;
  }
  return a;
};

// Окружность на полу (по часовой стрелке в мировых координатах)
const circlePts = (cx, cy, r, n = 20) =>
  Array.from({ length: n }, (_, i) => {
    const a = (i / n) * Math.PI * 2;
    return { x: cx + Math.cos(a) * r, y: cy + Math.sin(a) * r };
  });

const shadeColor = (color, k) => {
  const c = Phaser.Display.Color.IntegerToColor(color);
  return Phaser.Display.Color.GetColor(Math.min(255, c.red * k), Math.min(255, c.green * k), Math.min(255, c.blue * k));
};

// Призма: многоугольник основания (мир, по часовой) от высоты z0 до z1.
// Рисуются только грани, повёрнутые к камере, затем верх.
// skip — номера рёбер основания, грани которых не рисуем (внутренние стыки ломтиков)
const drawPrism = (g, base, z0, z1, color, topColor, edge = null, skip = null) => {
  const n = base.length;
  for (let i = 0; i < n; i++) {
    if (skip && skip.includes(i)) continue;
    const p = base[i], q = base[(i + 1) % n];
    const quad = [proj(p.x, p.y, z0), proj(q.x, q.y, z0), proj(q.x, q.y, z1), proj(p.x, p.y, z1)];
    if (screenArea(quad) <= 0) continue;
    // освещение: южные грани темнее, боковые чуть светлее
    const nx = q.y - p.y, ny = -(q.x - p.x), len = Math.hypot(nx, ny) || 1;
    const k = 0.9 + 0.12 * (nx / len) - 0.1 * (ny / len);
    g.fillStyle(shadeColor(color, k), 1).fillPoints(quad, true);
  }
  const top = base.map((p) => proj(p.x, p.y, z1));
  g.fillStyle(topColor, 1).fillPoints(top, true);
  if (edge !== null) g.lineStyle(1, edge, 0.6).strokePoints(top, true);
  return top;
};

// ── Роли ────────────────────────────────────────────────────────────────
// Станции окрашены в цвет роли: пользоваться ими может только астронавт этой роли.
// Серые (ANY) — общие. Класть предметы на любую станцию может кто угодно.
const ROLES = {
  S: { name: 'Scientist', color: 0xa25bd6 },
  E: { name: 'Engineer', color: 0xe05a5a },
  L: { name: 'Logistics', color: 0x7cc04a },
  N: { name: 'Navigator', color: 0x3fa7e0 },
  ANY: { name: 'anyone', color: 0x9aa3cf },
};
const hex = (c) => '#' + c.toString(16).padStart(6, '0');

// ── Карта ───────────────────────────────────────────────────────────────
// Стены — отрезки по линиям сетки: [x1, y1, x2, y2, высота?]
const WALLS = [
  [0, 0, 30, 0],                  // верх
  [0, 15, 30, 15, FRONT_WALL_H],  // низ
  [0, 0, 0, 15],                  // лево
  [30, 0, 30, 15],                // право
  [10.5, 0, 10.5, 6],             // перегородка Storage | Cargo (дверь 6..10)
  [10.5, 10, 10.5, 15],
  [20, 0, 20, 6],                 // перегородка Cargo | Launch bay (дверь 6..10)
  [20, 10, 20, 15],
];

// Названия отсеков на полу (в 3D-рендере они нарисованы на полу; здесь — для запасной отрисовки)
const ROOMS = [
  { text: 'STORAGE', x: 7.2, y: 7.5 },
  { text: 'LAUNCH BAY', x: 24.5, y: 8.8 },
];

// Станции: прямоугольник в клетках [x, y, ширина, высота], роль, высокая ли, тип:
//   source — выдаёт предмет груза; order / scale / fuel / engine — окна задач;
//   decor  — просто часть интерьера (с ней нельзя взаимодействовать).
// look — какую 3D-модель рисует рендер интерьера (tools/level-render).
const STATIONS = [
  // ── Storage
  { id: 'shelf',     name: 'Instrument Shelf', rect: [0, 2.5, 3, 6],        role: 'S', high: true, look: 'shelf', kind: 'catalog' },
  { id: 'analyzer',  name: 'Analyzer',         rect: [3.6, 0, 3.2, 2.2],    role: 'S', look: 'analyzer', kind: 'calibrate' },
  { id: 'labconsole', name: 'Lab Console',     rect: [7, 0, 3.2, 1.8],      role: 'S', look: 'labconsole', kind: 'science' },
  { id: 'workbench', name: 'Workbench',        rect: [0, 11.6, 4.3, 3.4],   role: 'E', look: 'workbench', kind: 'tools' },
  { id: 'o2',        name: 'O2 Storage',       rect: [4.5, 11.8, 2.6, 3.2], role: 'L', look: 'o2', kind: 'o2' },
  { id: 'supply',    name: 'Supply Rack',      rect: [7.3, 11.8, 2.9, 3.2], role: 'L', look: 'supply', kind: 'supply' },
  // ── Cargo
  { id: 'order',     name: 'Order Screen',     rect: [11.2, 0, 8.1, 0.8],   role: 'ANY', look: 'orderscreen', kind: 'order' },
  // Весы — не препятствие, а зона на полу: на неё кладут груз и встают сами
  { id: 'scale',     name: 'Scale',            rect: [11.5, 4.6, 7.5, 7.4], role: 'E', look: 'scale', kind: 'scale', zone: true },
  { id: 'launch',    name: 'Launch Control',   rect: [10.9, 12.6, 4.3, 2.4], role: 'N', look: 'launchcontrol', kind: 'engine' },
  { id: 'planning',  name: 'Mission Planning', rect: [15.4, 12.6, 4.4, 2.4], role: 'N', look: 'planning', kind: 'planning' },
  // ── Launch bay
  { id: 'hangar',    name: 'Hangar Door',      rect: [20.4, 0, 5.8, 1.1],   role: 'ANY', look: 'hangar', kind: 'decor' },
  { id: 'hatch',     name: 'Boarding Hatch',   rect: [26.4, 0, 1.7, 1.2],   role: 'ANY', look: 'hatch', kind: 'decor' },
  { id: 'fuelport',  name: 'Fuel Port',        rect: [28.2, 0, 1.8, 1.3],   role: 'N', look: 'fuelport', kind: 'fuel' },
  { id: 'fuelcells', name: 'Fuel Cells',       rect: [24.6, 6.2, 2.3, 1.7], role: 'E', look: 'fuelcells', kind: 'power' },
  { id: 'fueltanks', name: 'Fuel Tanks',       rect: [28, 3.6, 2, 7.4], role: 'N', high: true, look: 'fueltanks', kind: 'decor' },
  { id: 'suits',     name: 'Suit Locker',      rect: [21.4, 12.3, 8.6, 2.7], role: 'L', look: 'suits', kind: 'suits' },
];

// ── Физика миссии ───────────────────────────────────────────────────────
// Формула Циолковского: сколько топлива нужно, чтобы разогнать груз массой m на Δv.
// m_т = m · (e^(Δv / vₑ) − 1). Упрощение: учитываем только массу груза.
const DELTA_V = 3.6;   // км/с — перелёт с околоземной орбиты к Марсу
const V_EXHAUST = 4.4; // км/с — скорость истечения (водород + кислород)
const FUEL_FACTOR = Math.exp(DELTA_V / V_EXHAUST) - 1;

// ── Игроки ──────────────────────────────────────────────────────────────
const PLAYERS = [
  { x: tx(23.5), y: ty(9.5), role: 'N', model: 'robotdog', label: 'WASD, E', useName: 'E',
    up: [KC.W], left: [KC.A], down: [KC.S], right: [KC.D], use: [KC.E] },
  { x: tx(6), y: ty(10), role: 'E', model: 'bunny', label: 'arrows, Enter', useName: 'Enter',
    up: [KC.UP], left: [KC.LEFT], down: [KC.DOWN], right: [KC.RIGHT], use: [KC.ENTER] },
  { x: tx(6), y: ty(4.5), role: 'S', model: 'cat', label: "P L ; ', O", useName: 'O',
    up: [KC.P], left: [KC.L], down: [KC.SEMICOLON, KC.SEMICOLON_FIREFOX], right: [KC.QUOTES], use: [KC.O] },
  { x: tx(15.2), y: ty(3.2), role: 'L', model: 'bear', label: '8 4 5 6, 7', useName: '7',
    up: [KC.NUMPAD_EIGHT, KC.EIGHT], left: [KC.NUMPAD_FOUR, KC.FOUR],
    down: [KC.NUMPAD_FIVE, KC.FIVE], right: [KC.NUMPAD_SIX, KC.SIX],
    use: [KC.NUMPAD_SEVEN, KC.SEVEN] },
];
// Все герои появляются в одном месте — у ворот ангара, «квадратом» 2×2
const SPAWN = { x: tx(23.3), y: ty(3.3) };
const SPAWN_OFFSETS = [[-26, -22], [26, -22], [-26, 24], [26, 24]];
PLAYERS.forEach((p, i) => { p.x = SPAWN.x + SPAWN_OFFSETS[i][0]; p.y = SPAWN.y + SPAWN_OFFSETS[i][1]; });
for (const p of PLAYERS) p.color = ROLES[p.role].color;

// Шаг 1 — только комната. Задачи (выдача груза, окна, миссия) уже описаны ниже,
// но выключены, пока не дойдём до них. true — включить.
const TASKS_ENABLED = true;

// ── Доска заказов (Экран заказа) ───────────────────────────────────────
// Кастомный заказ миссии: тип, цель, длительность, сложность.
// Δv — примерно, от околоземной орбиты до цели; перелёт — в одну сторону.
const MISSION_TYPES = [
  { id: 'soil',  name: 'Soil sample',  desc: 'Land, drill and return samples', cargo: ['Drill', 'Sample containers'], returnTrip: true },
  { id: 'photo', name: 'Photo survey', desc: 'Image the surface from orbit',   cargo: ['High-res camera'] },
];
const TARGETS = [
  { name: 'Moon',   dv: 4.0, travel: 3 },
  { name: 'Mars',   dv: 3.6, travel: 210 },
  { name: 'Phobos',  dv: 4.5, travel: 210 },
  { name: 'Venus', dv: 3.5, travel: 150 },
  { name: 'Ceres', dv: 6.5, travel: 600 },
];
const DURATIONS = [30, 90, 180, 365, 540, 730, 1460]; // дней
// Очки: идеальная миссия на Easy = BASE_SCORE, на сложностях выше — с множителем.
// Множители растут быстрее, чем линейно: каждый уровень убирает целый слой помощи.
const BASE_SCORE = 1000;
const DIFFICULTIES = [
  { name: 'Easy', mult: 1,
    desc: 'Hints everywhere. Formulas come with the numbers already plugged in — you just do the math. ' +
          'Warnings pop up when something is wrong.' },
  { name: 'Normal', mult: 1.5,
    desc: 'Formulas are pinned on a sticky note next to each task window — plug the numbers in yourself. ' +
          'Warnings pop up when something is wrong.' },
  { name: 'Hard', mult: 2.5,
    desc: 'No warnings. The formulas you may need are shown only once, before the mission starts. ' +
          'Entering numbers and picking items is all on you.' },
  { name: 'Extreme', mult: 4,
    desc: '💀💀💀 Nothing is shown. No formulas, no hints, no warnings. One mistake and the mission is over.' },
];
const BOARD_W = 430;

// ── Вес героев ──────────────────────────────────────────────────────────
// Каждый от 55 до 80 кг, а средний по экипажу — в пределах 65–70 кг.
const HERO_MASS_MIN = 55, HERO_MASS_MAX = 80;
const HERO_MEAN_MIN = 65, HERO_MEAN_MAX = 70;
const rollCrewMasses = (n) => {
  for (;;) {
    const m = Array.from({ length: n }, () =>
      Math.round((HERO_MASS_MIN + Math.random() * (HERO_MASS_MAX - HERO_MASS_MIN)) * 10) / 10);
    const mean = m.reduce((a, b) => a + b, 0) / n;
    if (mean >= HERO_MEAN_MIN && mean <= HERO_MEAN_MAX) return m;
  }
};

// ── Каталог Instrument Shelf (Launch_Rush_Instrument_Shelf_Catalog.pdf) ──
// [id, название, категория, масса (ед.), мощность (ед.), роли, назначение]
// Масса и мощность — игровые единицы каталога. На весах 1 ед. массы = INSTRUMENT_KG кг.
const INSTRUMENT_KG = 10;
const INSTRUMENTS = [
  ['S01', 'Stereo panorama camera', 'CORE', 2, 1, 'Scientist', 'Stereo photos of rocks and landscape for terrain context and site selection.'],
  ['S02', 'Visible/near-IR spectrometer', 'CORE', 3, 2, 'Scientist', 'Reflected light by wavelength → surface/atmosphere composition during a flyby.'],
  ['S03', 'Crew radiation dosimeter', 'CORE', 1, 1, 'Scientist / Life Support', 'Tracks radiation dose and particle events; space-weather science packet.'],
  ['S04', 'Coring drill + sealed sample kit', 'CORE', 4, 2, 'Scientist', 'Extracts rock cores and seals them for laboratory analysis.'],
  ['S05', 'X-ray fluorescence analyzer (XRF)', 'CORE', 3, 3, 'Scientist', 'Detects elements in rock or soil samples.'],
  ['S06', 'Mars weather sensor suite', 'CORE', 2, 1, 'Scientist / Life Support', 'Air temperature, pressure, wind and dust for weather science and EVA planning.'],
  ['S07', 'Raman / fluorescence spectrometer', 'CONDITIONAL', 3, 3, 'Scientist', 'Laser-induced spectra of minerals and possible organic compounds.'],
  ['S08', 'Ground-penetrating radar', 'CONDITIONAL', 4, 3, 'Scientist / Navigator', 'Maps layering and structures under the soil.'],
  ['S09', 'Thermal infrared radiometer', 'CONDITIONAL', 2, 2, 'Scientist', 'Emitted IR → surface temperatures and thermal properties.'],
  ['S10', 'Magnetometer boom', 'CONDITIONAL', 2, 1, 'Scientist / Engineer', 'Magnetic-field strength and direction during cruise or at the surface.'],
  ['S11', 'Energetic particle detector', 'CONDITIONAL', 2, 2, 'Scientist / Life Support', 'Counts high-energy charged particles.'],
  ['S12', 'Atmospheric mass spectrometer', 'CONDITIONAL', 4, 4, 'Scientist', 'Identifies gases by mass-to-charge signatures.'],
  ['S13', 'Neutron spectrometer', 'CONDITIONAL', 3, 2, 'Scientist', 'Neutron signatures of hydrogen-rich material beneath the surface.'],
  ['S14', 'Microscopic imager', 'CONDITIONAL', 2, 2, 'Scientist', 'Close-up textures and grain structures of rocks and cores.'],
  ['S15', 'Laser-induced breakdown spectrometer', 'CONDITIONAL', 4, 4, 'Scientist', 'Laser pulses → elemental emission from a remote rock target.'],
  ['S16', 'Seismometer package', 'CONDITIONAL', 4, 1, 'Scientist / Engineer', 'Ground vibrations and marsquakes.'],
  ['S17', 'UV spectrograph', 'CONDITIONAL', 3, 2, 'Scientist', 'Ultraviolet spectra of the (upper) atmosphere.'],
  ['S18', 'Wide-angle context camera', 'CONDITIONAL', 1, 1, 'Scientist / Navigator', 'Broad-view imagery of clouds, dust, horizon and terrain.'],
  ['S19', 'Dust particle counter', 'CONDITIONAL', 2, 1, 'Scientist / Life Support', 'Airborne dust abundance and particle sizes.'],
  ['S20', 'Soil moisture / dielectric probe', 'CONDITIONAL', 2, 1, 'Scientist', 'Soil dielectric properties.'],
  ['S21', 'Trace-gas sensor', 'CONDITIONAL', 3, 3, 'Scientist', 'Tiny concentrations of a selected gas.'],
  ['S22', 'Sample oven / evolved-gas analyzer', 'CONDITIONAL', 4, 4, 'Scientist', 'Heats tiny samples and measures released gases.'],
  ['S23', 'Lidar unit', 'CONDITIONAL', 3, 3, 'Navigator / Scientist', 'Laser ranging of terrain elevations or dust layers.'],
  ['S24', 'Optical mineral microscope', 'CONDITIONAL', 2, 2, 'Scientist', 'Inspects grains under magnification and controlled light.'],
  ['S25', 'Biological culture incubator', 'DISTRACTOR', 5, 4, 'Scientist / Life Support', 'Cultures organisms under controlled conditions.'],
  ['S26', 'Ocean salinity / conductivity probe', 'DISTRACTOR', 2, 1, 'Scientist', 'Conductivity of liquid water.'],
  ['S27', 'Underwater sonar transducer', 'DISTRACTOR', 4, 3, 'Navigator / Scientist', 'Sound pulses through liquid water for depth mapping.'],
  ['S28', 'Ocean-plankton net', 'DISTRACTOR', 2, 0, 'Scientist', 'Collects plankton from a body of water.'],
  ['S29', 'Earth GPS handheld receiver', 'DISTRACTOR', 1, 1, 'Navigator', 'Receives Earth satellite navigation signals.'],
  ['S30', 'Terrestrial rain gauge', 'DISTRACTOR', 1, 0, 'Scientist', 'Measures liquid rainfall over time.'],
  ['S31', 'Deep-sea pressure logger', 'DISTRACTOR', 3, 1, 'Scientist / Engineer', 'Measures high pressures at ocean depth.'],
  ['S32', 'Botanical leaf chlorophyll meter', 'DISTRACTOR', 1, 1, 'Life Support / Scientist', 'Leaf optical response in a greenhouse.'],
].map(([id, name, cat, mass, power, roles, purpose]) => ({ id, name, cat, mass, power, roles, purpose }));
const INSTRUMENT_BY_ID = Object.fromEntries(INSTRUMENTS.map((i) => [i.id, i]));
const SCIENCE_CAPACITY = 12; // ед. массы научного груза
const POWER_BUDGET = 8;      // ед. мощности, которые одновременно тянут Fuel Cells

// Научные заказы (тикеты) каталога: какие приборы нужны. phase: F — в полёте, L — после посадки.
const TICKETS = [
  ['O01', 'Map Mars geology', ['S01', 'S05'], 'L', 170], ['O02', 'Cruise radiation log', ['S03'], 'F', 80],
  ['O03', 'Atmospheric flyby spectrum', ['S02'], 'F', 120], ['O04', 'Return a documented rock core', ['S04', 'S01'], 'L', 150],
  ['O05', 'Mars surface weather report', ['S06'], 'L', 90], ['O06', 'Search for organic signatures', ['S07', 'S04'], 'L', 180],
  ['O07', 'Map buried layers', ['S08'], 'L', 150], ['O08', 'Investigate heat patterns', ['S09'], 'F', 110],
  ['O09', 'Characterize magnetic environment', ['S10'], 'F', 100], ['O10', 'Measure upper-atmosphere UV', ['S17'], 'F', 110],
  ['O11', 'Marsquake watch', ['S16'], 'L', 140], ['O12', 'Trace gas investigation', ['S12', 'S21'], 'L', 160],
  ['O13', 'Track charged particles', ['S11'], 'F', 105], ['O14', 'Search for buried hydrogen', ['S13'], 'L', 140],
  ['O15', 'Inspect rock grains', ['S14', 'S24'], 'L', 115], ['O16', 'Remote elemental rock scan', ['S15'], 'L', 145],
  ['O17', 'Cloud and dust overview', ['S18'], 'F', 65], ['O18', 'Measure airborne dust', ['S19'], 'L', 100],
  ['O19', 'Soil dielectric survey', ['S20'], 'L', 110], ['O20', 'Measure released volatiles', ['S22', 'S04'], 'L', 175],
  ['O21', 'High-resolution terrain relief', ['S23'], 'L', 130],
].map(([id, name, needs, phase, pts]) => ({ id, name, needs, phase, pts }));

// Инструменты Engineer (отдельно от научной полки — так требует каталог)
const TOOLS = [
  { id: 'T1', name: 'Torque wrench', mass: 4 },
  { id: 'T2', name: 'Digital multimeter', mass: 2 },
  { id: 'T3', name: 'Screwdriver + fuse puller', mass: 2 },
  { id: 'T4', name: 'Leak patch kit', mass: 3 },
  { id: 'T5', name: 'Reference lamp', mass: 3 },
  { id: 'T6', name: 'Drill bits + tubes', mass: 5 },
  { id: 'T7', name: 'Suit O2 coupling', mass: 3 },
  { id: 'T8', name: 'Filter + dust brush', mass: 2 },
];
// Запасы Logistics: [станция, предметы]
const SUPPLIES = {
  o2: [{ id: 'O2', name: 'O2 tank', mass: 30, stock: 6 }],
  supply: [{ id: 'FD', name: 'Food crate', mass: 25, stock: 4 }, { id: 'WT', name: 'Water container', mass: 30, stock: 4 }],
  suits: [{ id: 'SU', name: 'Spacesuit', mass: 50, stock: 4 }],
};
const CAT_COLORS = { CORE: '#46a35a', CONDITIONAL: '#d08a1a', DISTRACTOR: '#c0392b' };

const WIN_W = 250;          // ширина окна задачи, px
const STATION_REACH = 30;   // насколько близко (от края хитбокса) надо подойти к станции, px
const FUEL_DIGITS = 4;

export class HangarScene extends Phaser.Scene {
  constructor() { super('Hangar'); }

  preload() {
    const v = window.BUILD || Date.now();
    // Интерьер, отрендеренный в 3D (tools/level-render): слои-картинки + их положение и глубина.
    // Если файлов нет — карта рисуется простыми коробками, как раньше.
    this.load.json('levelmeta', `assets/level/level.json?v=${v}`);
    this.load.pack('levelpack', `assets/level/pack.json?v=${v}`);
    for (const name of ['robotdog', 'bunny', 'cat', 'bear']) {
      this.load.spritesheet(name, `assets/crew/${name}.png?v=${v}`,
        { frameWidth: SPRITE.frame, frameHeight: SPRITE.frameH });
    }
  }

  create() {
    // Чёткость: игра рисуется во внутреннем разрешении 1280×720 × RES (см. main.js),
    // а вся логика остаётся в координатах 1280×720 — камера просто увеличена.
    const RES = window.RES || 1;
    this.cameras.main.setZoom(RES).centerOn(640, 360);
    this.physics.world.setBounds(0, 0, 1280, 720);
    // Весь текст — в том же разрешении и нормальным шрифтом (по умолчанию у Phaser тонкий Courier)
    const addText = this.add.text.bind(this.add);
    this.add.text = (x, y, str, style = {}) => addText(x, y, str, {
      fontFamily: '"Segoe UI", Roboto, Arial, sans-serif', resolution: RES, ...style,
    });

    this.buildLevel();
    this.items = [];
    this.mission = { fuelOk: false, fuelValue: null, launched: false, failed: false };
    this.tickets = null; this.mistakes = 0;
    // запасы станций на старте
    for (const ins of INSTRUMENTS) ins.stock = 1;
    for (const t of TOOLS) t.stock = 1;
    for (const list of Object.values(SUPPLIES)) for (const s2 of list) s2.stock = s2.stock0 ?? (s2.stock0 = s2.stock);
    this.hl = this.add.graphics().setDepth(9000); // подсветка станций
    // Пока задачи выключены — один тестовый ящик в грузовом отсеке, чтобы проверять переноску

    const kb = this.input.keyboard;
    const bind = (codes) => codes.map((c) => kb.addKey(c, true));

    const crewMasses = rollCrewMasses(PLAYERS.length);
    this.players = PLAYERS.map((cfg, idx) => {
      // Физическое тело — невидимый круг на плоскости; рисуем героя отдельно
      const body = this.add.circle(cfg.x, cfg.y, PLAYER_RADIUS, cfg.color).setVisible(false);
      this.physics.add.existing(body);
      body.body.setCircle(PLAYER_RADIUS);
      body.body.setCollideWorldBounds(true);
      return {
        cfg,
        role: cfg.role,
        body,
        facing: Math.PI / 2,                         // направление взгляда, 0 = вправо
        cone: this.add.graphics().setDepth(-500),    // конус обзора (лежит на полу)
        gfx: this.add.graphics().setDepth(-400),     // тень и цветное кольцо на полу
        sprite: this.add.image(cfg.x, cfg.y, cfg.model, 0)
          .setOrigin(SPRITE.footX / SPRITE.frame, SPRITE.footY / SPRITE.frameH),
        walkPhase: 0,
        keys: {
          up: bind(cfg.up), left: bind(cfg.left), down: bind(cfg.down),
          right: bind(cfg.right), use: bind(cfg.use),
        },
        carrying: null,
        win: null,      // открытое окно задачи
        mass: crewMasses[idx], // вес героя, кг (узнать можно только на весах)
      };
    });

    this.physics.world.on('worldstep', (delta) => {
      this.stepItems(delta);
      this.resolvePushes();
    });

    const help = this.players.map((pl, i) =>
      `${i + 1}: ${ROLES[pl.role].name} (${pl.cfg.label})`).join('   ');
    this.add.text(16, 10, help, { color: '#ffffff', fontSize: '13px' }).setDepth(10000);
    this.add.text(16, 28, 'Action key — pick up / put down / use stations of your color (gray — anyone)',
      { color: '#9aa3cf', fontSize: '12px' }).setDepth(10000);
    this.banner = this.add.text(640, 360, '', {
      color: '#ffffff', fontSize: '34px', fontStyle: 'bold', backgroundColor: '#0f1430cc',
      padding: { x: 24, y: 14 }, align: 'center',
    }).setOrigin(0.5).setDepth(30000).setVisible(false);
  }

  // ── Уровень ────────────────────────────────────────────────────────────
  buildLevel() {
    const meta = this.cache.json.get('levelmeta');
    this.textured = !!meta && meta.layers.every((L) => this.textures.exists(L.key));
    if (this.textured) {
      for (const L of meta.layers) {
        this.add.image(L.x, L.y, L.key).setOrigin(0).setScale(1 / meta.scale).setDepth(L.depth);
      }
    }
    const g = this.add.graphics().setDepth(-1000).setVisible(!this.textured);
    const corner = (gx, gy) => proj(tx(gx), ty(gy));
    g.fillStyle(0x141a35, 1).fillPoints(
      [corner(0, 0), corner(GRID_W, 0), corner(GRID_W, GRID_H), corner(0, GRID_H)], true);
    g.lineStyle(1, 0xffffff, 0.05);
    for (let i = 0; i <= GRID_W; i++) {
      const a = corner(i, 0), b = corner(i, GRID_H);
      g.lineBetween(a.x, a.y, b.x, b.y);
    }
    for (let j = 0; j <= GRID_H; j++) {
      const a = corner(0, j), b = corner(GRID_W, j);
      g.lineBetween(a.x, a.y, b.x, b.y);
    }
    // Названия отсеков на полу
    for (const r of this.textured ? [] : ROOMS) {
      const p = proj(tx(r.x), ty(r.y));
      this.add.text(p.x, p.y, r.text, { color: '#5c6699', fontSize: '18px' }).setOrigin(0.5).setDepth(-900);
    }

    this.solids = []; // { l, t, r, b, high, h, station? } в мировых px
    this.boxes = [];

    // Станции
    this.stations = STATIONS.map((def) => {
      const [x, y, w, h] = def.rect;
      // станции у внешних стен прижимаем к их внутренней грани, чтобы не залезали в стену
      const l = Math.max(tx(x), tx(0) + WALL / 2), t = Math.max(ty(y), ty(0) + WALL / 2);
      const r = Math.min(tx(x + w), tx(GRID_W) - WALL / 2), b = Math.min(ty(y + h), ty(GRID_H) - WALL / 2);
      if (def.zone) return this.buildScaleZone(def, l, t, r, b);
      const hgt = def.high ? HIGH_H : LOW_H;
      const role = ROLES[def.role];
      if (this.textured) {
        // подпись — «пузырёк» над станцией (см. makeBubbles)
        const st = { ...def, l, t, r, b, h: hgt, label: null, given: false, anchor: proj((l + r) / 2, (t + b) / 2, hgt + 10) };
        st.solid = { l, t, r, b, high: !!def.high, h: hgt, station: st };
        this.solids.push(st.solid);
        return st;
      }
      const box = def.high
        ? this.addBox(l, t, r, b, hgt, 0x3a4170, 0x5a6394, 0xe0e6ff)
        : this.addBox(l, t, r, b, hgt, 0x353c66, 0x47507c, 0x8c96c8);
      // цветная полоса роли у переднего края крышки
      const stripe = [proj(l, b - 7, hgt), proj(r, b - 7, hgt), proj(r, b, hgt), proj(l, b, hgt)];
      box.g.fillStyle(role.color, 1).fillPoints(stripe, true);
      const c = proj((l + r) / 2, (t + b) / 2 - 4, hgt);
      const label = this.add.text(c.x, c.y, def.name, {
        color: '#e6e9ff', fontSize: '12px', align: 'center',
        wordWrap: { width: Math.max(40, proj(r, b, hgt).x - proj(l, b, hgt).x - 6) },
      }).setOrigin(0.5).setDepth(b + 0.01);
      const st = { ...def, l, t, r, b, h: hgt, box, label, given: false };
      const solid = { l, t, r, b, high: !!def.high, h: hgt, station: st };
      st.solid = solid;
      this.solids.push(solid);
      return st;
    });

    // Стены
    for (const [x1, y1, x2, y2, hgt = WALL_H] of WALLS) {
      const l = Math.min(tx(x1), tx(x2)) - WALL / 2;
      const t = Math.min(ty(y1), ty(y2)) - WALL / 2;
      const r = Math.max(tx(x1), tx(x2)) + WALL / 2;
      const b = Math.max(ty(y1), ty(y2)) + WALL / 2;
      // Внешние боковые стены: за ними ничего нет, поэтому рисуем их раньше всего, что в комнате.
      // Остальные стены чуть «позади» станций той же глубины — станции у стен рисуются поверх.
      const outerSide = x1 === x2 && (x1 === 0 || x1 === GRID_W);
      if (!this.textured) this.addBox(l, t, r, b, hgt, 0x9aa3cf, 0xe0e6ff, 0xffffff, -0.5, outerSide ? -480 : null);
      this.solids.push({ l, t, r, b, high: true, h: hgt });
    }
    if (this.textured) this.makeBubbles();
    // Дверные проёмы — пунктир на полу
    const dg = this.add.graphics().setDepth(-950).setVisible(!this.textured);
    for (const x of [10.5, 20]) {
      for (let y = 6; y < 10; y += 0.5) {
        const a = proj(tx(x), ty(y)), b = proj(tx(x), ty(y + 0.25));
        dg.lineStyle(4, 0x7cc04a, 0.7).lineBetween(a.x, a.y, b.x, b.y);
      }
    }
  }

  // Пузырьки-подписи над станциями: название + подчёркивание цветом роли, которая с ней работает
  makeBubbles() {
    const placed = [];
    const list = [...this.stations].sort((a, b) => a.anchor.y - b.anchor.y);
    for (const st of list) {
      const roleColor = st.role === 'ANY' ? 0x9aa3b8 : ROLES[st.role].color;
      const text = this.add.text(0, 0, st.name, {
        color: '#1d2b4a', fontSize: '12px', fontStyle: 'bold', align: 'center',
      }).setOrigin(0.5, 0);
      const padX = 9, padY = 4, lineH = 3, w = Math.ceil(text.width) + padX * 2, h = Math.ceil(text.height) + padY * 2 + lineH + 2, tail = 6;
      // позиция: хвостик указывает на станцию; если наезжает на другой пузырёк — поднимаем
      let x = Phaser.Math.Clamp(st.anchor.x, w / 2 + 4, 1280 - w / 2 - 4), y = st.anchor.y - tail - h;
      const hit = (px, py) => placed.find((q) => px - w / 2 < q.x + q.w / 2 + 3 && px + w / 2 > q.x - q.w / 2 - 3 && py < q.y + q.h + 3 && py + h > q.y - 3);
      for (let guard = 0, q; (q = hit(x, y)) && guard < 10; guard++) y = q.y - h - 4;
      placed.push({ x, y, w, h });
      const g = this.add.graphics();
      g.fillStyle(0x0b1630, 0.18).fillRoundedRect(-w / 2 + 1, 2, w, h, 8);           // тень
      g.fillStyle(0xffffff, 0.96).fillRoundedRect(-w / 2, 0, w, h, 8);
      g.lineStyle(1.5, 0xc9d3e3, 1).strokeRoundedRect(-w / 2, 0, w, h, 8);
      const tx0 = Phaser.Math.Clamp(st.anchor.x - x, -w / 2 + 10, w / 2 - 10), ty0 = st.anchor.y - y;
      g.fillStyle(0xffffff, 0.96).fillTriangle(tx0 - 6, h - 1, tx0 + 6, h - 1, tx0, Math.max(h + tail, Math.min(ty0, h + 40)));
      g.fillStyle(roleColor, 1).fillRoundedRect(-w / 2 + 8, h - padY - lineH + 1, w - 16, lineH, 1.5); // подчёркивание роли
      text.setPosition(0, padY);
      st.bubble = this.add.container(x, y, [g, text]).setDepth(15000);
    }
  }

  // Объёмный блок. Длинные по глубине блоки (стены по бокам, высокие шкафы) режем на
  // ломтики по полклетки: каждый сортируется по своей Y, иначе такой блок целиком
  // перекрывал бы всё, что стоит рядом с ним.
  // Весы-зона: жёлто-чёрная разметка и платформа на полу + табло на стойке у дальнего края
  buildScaleZone(def, l, t, r, b) {
    const g = this.add.graphics().setDepth(-940).setVisible(!this.textured);
    const P = (x, y) => proj(x, y, 0);
    // платформа
    g.fillStyle(0x1f2750, 1).fillPoints([P(l, t), P(r, t), P(r, b), P(l, b)], true);
    g.lineStyle(1, 0x3a4680, 0.6);
    for (let x = l + 20; x < r; x += 20) { const a = P(x, t), c = P(x, b); g.lineBetween(a.x, a.y, c.x, c.y); }
    for (let y = t + 20; y < b; y += 20) { const a = P(l, y), c = P(r, y); g.lineBetween(a.x, a.y, c.x, c.y); }
    // разметка по периметру: полосы 12 px, чередуем жёлтый и чёрный
    const band = 8, seg = 12;
    const edge = (x0, y0, x1, y1, nx, ny) => {
      const len = Math.hypot(x1 - x0, y1 - y0), ux = (x1 - x0) / len, uy = (y1 - y0) / len;
      for (let d = 0, i = 0; d < len; d += seg, i++) {
        const e = Math.min(len, d + seg);
        const a = { x: x0 + ux * d, y: y0 + uy * d }, c = { x: x0 + ux * e, y: y0 + uy * e };
        g.fillStyle(i % 2 ? 0x111111 : 0xf2c230, 1).fillPoints([
          P(a.x, a.y), P(c.x, c.y), P(c.x + nx * band, c.y + ny * band), P(a.x + nx * band, a.y + ny * band)], true);
      }
    };
    edge(l, t, r, t, 0, 1); edge(r, t, r, b, -1, 0); edge(r, b, l, b, 0, -1); edge(l, b, l, t, 1, 0);
    // надпись на полу
    const lp = P((l + r) / 2, b - 22);
    if (!this.textured) this.add.text(lp.x, lp.y, 'CARGO SCALE', { color: '#5c6699', fontSize: '13px', fontStyle: 'bold' })
      .setOrigin(0.5).setDepth(-930);

    // табло на стойке за дальним краем зоны (сама стойка — препятствие)
    const cx = (l + r) / 2, sw = 64, sl = cx - sw / 2, sr = cx + sw / 2, sb = t - 2, stt = sb - 10, sh = 56;
    if (!this.textured) this.addBox(sl, stt, sr, sb, sh, 0x2a3266, 0x3a4170, 0x8c96c8);
    const scaleAnchor = proj(cx, (stt + sb) / 2, sh + 8);
    this.solids.push({ l: sl, t: stt, r: sr, b: sb, high: false, h: sh });
    const f0 = proj(sl + 4, sb, sh - 4), f1 = proj(sr - 4, sb, 20); // как экран стойки в 3D-рендере
    const dg = this.add.graphics().setDepth(sb + 0.01);
    dg.fillStyle(0x07090f, 1).fillRoundedRect(f0.x, f0.y, f1.x - f0.x, f1.y - f0.y, 4);
    dg.lineStyle(1, 0x3a4170, 1).strokeRoundedRect(f0.x, f0.y, f1.x - f0.x, f1.y - f0.y, 4);
    const tc = { x: (f0.x + f1.x) / 2, y: (f0.y + f1.y) / 2 };
    const digital = { fontFamily: 'Consolas, "Courier New", monospace', fontSize: '14px', fontStyle: 'bold' };
    // «призрачные» нули под цифрами, как на настоящем табло
    this.scaleGhost = this.add.text(tc.x - 5, tc.y, '8888.8', { ...digital, color: '#2a2410' }).setOrigin(0.5).setDepth(sb + 0.02);
    this.scaleText = this.add.text(tc.x - 5, tc.y, '', { ...digital, color: '#ffb020' }).setOrigin(0.5).setDepth(sb + 0.03);
    this.add.text(tc.x + this.scaleGhost.width / 2 - 4, tc.y + 3, 'kg', { color: '#ffb020', fontSize: '8px', fontStyle: 'bold' })
      .setOrigin(0, 0.5).setDepth(sb + 0.03);
    this.scaleShown = 0;

    const st = { ...def, l, t, r, b, h: 0, label: null, given: false, anchor: scaleAnchor,
      hit: { l: sl - 6, t: stt, r: sr + 6, b: sb + 4, h: sh } }; // взаимодействуем со стойкой табло
    st.solid = null;
    this.scaleZone = st;
    return st;
  }

  inScaleZone(x, y) {
    const z = this.scaleZone;
    return !!z && x >= z.l && x <= z.r && y >= z.t && y <= z.b;
  }

  // Сколько сейчас показывают весы: всё, что лежит в зоне, и герои, стоящие в ней (с тем, что в руках)
  scaleReading() {
    let m = 0;
    for (const it of this.items) if (!it.carrier && !it.support && this.inScaleZone(it.x, it.y)) m += it.mass;
    for (const pl of this.players) {
      if (!this.inScaleZone(pl.body.x, pl.body.y)) continue;
      m += pl.mass + (pl.carrying ? pl.carrying.mass : 0);
    }
    return m;
  }

  updateScaleDisplay(dt) {
    if (!this.scaleText) return;
    const target = this.scaleReading();
    // табло «доезжает» до значения за доли секунды, как настоящие весы
    this.scaleShown += (target - this.scaleShown) * Math.min(1, dt * 8);
    if (Math.abs(target - this.scaleShown) < 0.05) this.scaleShown = target;
    const v = Math.min(9999.9, Math.max(0, this.scaleShown));
    const str = v.toFixed(1).padStart(6, '0');
    // ведущие нули оставляем «призрачными», яркими рисуем только значащие цифры
    const lead = str.match(/^0*(?=\d+\.)/)[0].length;
    this.scaleText.setText(' '.repeat(lead) + str.slice(lead));
  }

  addBox(l, t, r, b, h, sideColor, topColor, edgeColor, depthBias = 0, fixedDepth = null) {
    const SLICE = TILE / 2;
    const parts = [];
    if (b - t > TILE * 2 && fixedDepth === null) {
      for (let y0 = t; y0 < b - 0.01; y0 += SLICE) parts.push([y0, Math.min(b, y0 + SLICE)]);
    } else {
      parts.push([t, b]);
    }
    let g;
    parts.forEach(([y0, y1], i) => {
      g = this.add.graphics().setDepth(fixedDepth !== null ? fixedDepth : y1 + depthBias);
      const base = [{ x: l, y: y0 }, { x: r, y: y0 }, { x: r, y: y1 }, { x: l, y: y1 }];
      // внутренние стыки между ломтиками не рисуем (ребро 0 — север, 2 — юг)
      const skip = [];
      if (i > 0) skip.push(0);
      if (i < parts.length - 1) skip.push(2);
      drawPrism(g, base, 0, h, sideColor, topColor, parts.length > 1 ? null : edgeColor, skip);
    });
    // g — самый ближний к камере ломтик: на нём рисуем полосу роли
    const box = { g, l, t, r, b, h };
    this.boxes.push(box);
    return box;
  }

  // ── Предметы ───────────────────────────────────────────────────────────
  createItem(def, color, x, y) {
    const it = {
      x, y, rotation: 0, z: 0, support: null, carrier: null, vx: 0, vy: 0,
      name: def.name, mass: def.mass, color,
      gfx: this.add.graphics(),
      label: this.add.text(0, 0, `${def.code ? def.code + ' · ' : ''}${def.mass} kg`, {
        color: '#ffffff', fontSize: '11px', backgroundColor: '#0f1430aa', padding: { x: 3, y: 1 },
      }).setOrigin(0.5, 1),
    };
    this.items.push(it);
    return it;
  }

  drawItem(it, highlight) {
    const g = it.gfx;
    const half = ITEM_SIZE / 2;
    const z0 = it.carrier ? HOLD_Z : it.z, z1 = z0 + ITEM_SIZE;
    const cs = Math.cos(it.rotation), sn = Math.sin(it.rotation);
    const corners = [[-half, -half], [half, -half], [half, half], [-half, half]]
      .map(([u, v]) => ({ x: it.x + cs * u - sn * v, y: it.y + sn * u + cs * v }));
    // в руках куб рисуется сразу ПОЗАДИ спрайта героя (в спрайте на его месте вырез)
    const depth = it.carrier ? it.carrier.body.y - 0.5 : it.support ? it.support.b + 0.02 : it.y;
    g.clear().setDepth(depth);
    if (it.carrier) {
      g.fillStyle(0x000000, 0.25).fillPoints(circlePts(it.x, it.y, half).map((p) => proj(p.x, p.y, 0)), true);
    }
    const top = drawPrism(g, corners, z0, z1, shadeColor(it.color, 0.95), shadeColor(it.color, 1.25));
    if (highlight) g.lineStyle(3, 0xffffff, 1).strokePoints(top, true);
    const lp = proj(it.x, it.y, z1 + 4);
    it.label.setPosition(lp.x, lp.y - 2).setDepth(depth + 0.01).setVisible(!it.carrier || highlight);
  }

  // ── Столкновения ───────────────────────────────────────────────────────
  circleVsRect(cx, cy, R, s) {
    const px = Phaser.Math.Clamp(cx, s.l, s.r);
    const py = Phaser.Math.Clamp(cy, s.t, s.b);
    const dx = cx - px, dy = cy - py;
    const d = Math.hypot(dx, dy);
    if (d >= R) return null;
    if (d > 0) return { nx: dx / d, ny: dy / d, depth: R - d };
    const opts = [[cx - s.l, -1, 0], [s.r - cx, 1, 0], [cy - s.t, 0, -1], [s.b - cy, 0, 1]];
    opts.sort((a, b) => a[0] - b[0]);
    return { nx: opts[0][1], ny: opts[0][2], depth: opts[0][0] + R };
  }

  pushOutOfSolid(body, s, cx = body.center.x, cy = body.center.y, R = PLAYER_RADIUS) {
    const hit = this.circleVsRect(cx, cy, R, s);
    if (!hit) return;
    const { nx, ny, depth } = hit;
    body.position.x += nx * depth;
    body.position.y += ny * depth;
    body.updateCenter();
    const vn = body.velocity.x * nx + body.velocity.y * ny;
    if (vn < 0) body.velocity.set(body.velocity.x - nx * vn, body.velocity.y - ny * vn);
  }

  // Лежащие на полу предметы: движение по инерции и трение
  stepItems(delta) {
    for (const it of this.items) {
      if (it.carrier || it.support) continue;
      it.x += it.vx * delta;
      it.y += it.vy * delta;
      const sp = Math.hypot(it.vx, it.vy);
      const ns = Math.max(0, sp - ITEM_FRICTION * delta);
      if (ns === 0) { it.vx = 0; it.vy = 0; } else { it.vx *= ns / sp; it.vy *= ns / sp; }
    }
  }

  resolveFloorItems(clamp) {
    for (const it of this.items) {
      if (it.carrier || it.support) continue;
      for (const pl of this.players) {
        const b = pl.body.body;
        let nx = it.x - b.center.x, ny = it.y - b.center.y;
        let dist = Math.hypot(nx, ny);
        const min = ITEM_RADIUS + PLAYER_RADIUS;
        if (dist >= min) continue;
        if (dist === 0) { nx = 1; ny = 0; dist = 1; }
        nx /= dist; ny /= dist;
        const mp = pl.moving ? 1 : IDLE_MASS;
        const overlap = min - dist;
        const shareItem = mp / (mp + ITEM_MASS), sharePl = ITEM_MASS / (mp + ITEM_MASS);
        it.x += nx * overlap * shareItem; it.y += ny * overlap * shareItem;
        b.position.x -= nx * overlap * sharePl; b.position.y -= ny * overlap * sharePl;
        clamp(b);
        const pv = b.velocity.x * nx + b.velocity.y * ny;
        const iv = it.vx * nx + it.vy * ny;
        if (pv > iv) { it.vx += nx * (pv - iv); it.vy += ny * (pv - iv); }
      }
      // предметы на полу не залезают друг в друга
      for (const o of this.items) {
        if (o === it || o.carrier || o.support) continue;
        let nx = it.x - o.x, ny = it.y - o.y;
        let dist = Math.hypot(nx, ny);
        const min = ITEM_RADIUS * 2;
        if (dist >= min) continue;
        if (dist === 0) { nx = 1; ny = 0; dist = 1; }
        nx /= dist; ny /= dist;
        const ov = (min - dist) / 2;
        it.x += nx * ov; it.y += ny * ov; o.x -= nx * ov; o.y -= ny * ov;
      }
      for (const s of this.solids) {
        const hit = this.circleVsRect(it.x, it.y, ITEM_RADIUS, s);
        if (!hit) continue;
        it.x += hit.nx * hit.depth; it.y += hit.ny * hit.depth;
        const vn = it.vx * hit.nx + it.vy * hit.ny;
        if (vn < 0) { it.vx -= hit.nx * vn; it.vy -= hit.ny * vn; }
      }
      const wb = this.physics.world.bounds;
      it.x = Phaser.Math.Clamp(it.x, wb.x + ITEM_RADIUS, wb.right - ITEM_RADIUS);
      it.y = Phaser.Math.Clamp(it.y, wb.y + ITEM_RADIUS, wb.bottom - ITEM_RADIUS);
    }
  }

  resolvePushes() {
    const ps = this.players;
    const minDist = PLAYER_RADIUS * 2;
    const wb = this.physics.world.bounds;
    const clamp = (body) => {
      body.position.x = Phaser.Math.Clamp(body.position.x, wb.x, wb.right - body.width);
      body.position.y = Phaser.Math.Clamp(body.position.y, wb.y, wb.bottom - body.height);
      body.updateCenter();
    };
    for (let iter = 0; iter < 3; iter++) {
      for (let i = 0; i < ps.length; i++) {
        for (let j = i + 1; j < ps.length; j++) {
          const a = ps[i].body.body, b = ps[j].body.body;
          let nx = b.center.x - a.center.x, ny = b.center.y - a.center.y;
          let dist = Math.hypot(nx, ny);
          if (dist >= minDist) continue;
          if (dist === 0) { nx = 1; ny = 0; dist = 1; }
          nx /= dist; ny /= dist;
          const ma = ps[i].moving ? 1 : IDLE_MASS;
          const mb = ps[j].moving ? 1 : IDLE_MASS;
          const overlap = minDist - dist;
          const shareA = mb / (ma + mb), shareB = ma / (ma + mb);
          a.position.x -= nx * overlap * shareA; a.position.y -= ny * overlap * shareA;
          b.position.x += nx * overlap * shareB; b.position.y += ny * overlap * shareB;
          clamp(a); clamp(b);
        }
      }
      // Предмет в руках — часть хитбокса героя: толкает других героев
      for (const owner of ps) {
        if (!owner.carrying) continue;
        const ob = owner.body.body;
        for (const other of ps) {
          if (other === owner) continue;
          const b = other.body.body;
          const ix = ob.center.x + Math.cos(owner.facing) * HOLD_DIST;
          const iy = ob.center.y + Math.sin(owner.facing) * HOLD_DIST;
          let nx = b.center.x - ix, ny = b.center.y - iy;
          let dist = Math.hypot(nx, ny);
          const min = ITEM_RADIUS + PLAYER_RADIUS;
          if (dist >= min) continue;
          if (dist === 0) { nx = 1; ny = 0; dist = 1; }
          nx /= dist; ny /= dist;
          const ma = owner.moving ? 1 : IDLE_MASS;
          const mb = other.moving ? 1 : IDLE_MASS;
          const overlap = min - dist;
          const shareA = mb / (ma + mb), shareB = ma / (ma + mb);
          ob.position.x -= nx * overlap * shareA; ob.position.y -= ny * overlap * shareA;
          b.position.x += nx * overlap * shareB; b.position.y += ny * overlap * shareB;
          clamp(ob); clamp(b);
        }
      }
      for (const pl of ps) {
        for (const s of this.solids) this.pushOutOfSolid(pl.body.body, s);
      }
      this.resolveFloorItems(clamp);
      for (const pl of ps) {
        if (!pl.carrying) continue;
        const b = pl.body.body;
        for (const s of this.solids) {
          if (!s.high) continue;
          const ix = b.center.x + Math.cos(pl.facing) * HOLD_DIST;
          const iy = b.center.y + Math.sin(pl.facing) * HOLD_DIST;
          this.pushOutOfSolid(b, s, ix, iy, ITEM_RADIUS);
        }
      }
    }
  }

  // ── Взгляд и цели ──────────────────────────────────────────────────────
  inView(pl, x, y, range = VIEW_RANGE) {
    const p = pl.body;
    if (Phaser.Math.Distance.Between(p.x, p.y, x, y) > range) return false;
    const toTarget = Phaser.Math.Angle.Between(p.x, p.y, x, y);
    const diff = Phaser.Math.Angle.Wrap(toTarget - pl.facing);
    return Math.abs(diff) <= VIEW_ANGLE / 2;
  }

  // Ближайший свободный предмет в конусе обзора
  targetItem(pl) {
    let best = null, bd = Infinity;
    for (const it of this.items) {
      if (it.carrier || !this.inView(pl, it.x, it.y)) continue;
      const d = Phaser.Math.Distance.Between(pl.body.x, pl.body.y, it.x, it.y);
      if (d < bd) { bd = d; best = it; }
    }
    return best;
  }

  // Станция прямо перед героем: ближайшая точка её прямоугольника рядом и в конусе
  targetStation(pl) {
    let best = null, bd = Infinity;
    const { x, y } = pl.body;
    for (const st of this.stations) {
      const R = st.hit || st;
      const px = Phaser.Math.Clamp(x, R.l, R.r), py = Phaser.Math.Clamp(y, R.t, R.b);
      const d = Math.hypot(px - x, py - y);
      if (st.kind === 'decor' || d > PLAYER_RADIUS + STATION_REACH) continue;
      // точку чуть внутри станции, по направлению взгляда, тоже проверяем
      const fx = x + Math.cos(pl.facing) * (PLAYER_RADIUS + 12), fy = y + Math.sin(pl.facing) * (PLAYER_RADIUS + 12);
      const facingIt = this.inView(pl, px, py) || (fx >= R.l && fx <= R.r && fy >= R.t && fy <= R.b);
      if (!facingIt) continue;
      if (d < bd) { bd = d; best = st; }
    }
    return best;
  }

  canUse(pl, st) { return st.role === 'ANY' || st.role === pl.role; }

  // ── Миссия ─────────────────────────────────────────────────────────────
  scaleStation() { return this.stations.find((s) => s.kind === 'scale'); }
  itemsOnScale() { return this.items.filter((it) => !it.carrier && !it.support && this.inScaleZone(it.x, it.y)); }
  loadedMass() { return this.itemsOnScale().reduce((a, it) => a + it.mass, 0); }
  crewMass() { return this.players.reduce((a, p) => a + p.mass, 0); }
  // Стартовая масса: весь груз в зоне весов + экипаж (каждого надо взвесить)
  launchMass() { return Math.round((this.loadedMass() + this.crewMass()) * 10) / 10; }
  orderTarget() { return TARGETS[this.order ? this.order.target : 1]; }
  fuelFactor() { return Math.exp(this.orderTarget().dv / V_EXHAUST) - 1; }
  requiredFuel() { return Math.round(this.launchMass() * this.fuelFactor()); }
  difficulty() { return this.order ? this.order.difficulty : 0; } // 0 Easy … 3 Extreme
  packedInstruments() { return this.itemsOnScale().filter((it) => it.type === 'instrument'); }
  ticketReady(tk) { const ids = new Set(this.packedInstruments().map((it) => it.code)); return tk.needs.every((n) => ids.has(n)); }

  // Тикеты под заказ: 3 случайных подходящих по типу миссии, чтобы вместе влезали в научную ёмкость
  rollTickets(order) {
    const phase = MISSION_TYPES[order.type].id === 'photo' ? 'F' : 'L';
    const pool = TICKETS.filter((t) => t.phase === phase);
    for (let guard = 0; guard < 500; guard++) {
      const pick = Phaser.Utils.Array.Shuffle([...pool]).slice(0, 3);
      const ids = new Set(pick.flatMap((t) => t.needs));
      const mass = [...ids].reduce((a, id) => a + INSTRUMENT_BY_ID[id].mass, 0);
      if (mass <= SCIENCE_CAPACITY) return pick;
    }
    return pool.slice(0, 2);
  }

  // Ошибка игрока: на Extreme — сразу провал миссии
  mistake(st, text) {
    this.mistakes = (this.mistakes || 0) + 1;
    if (this.difficulty() === 3) {
      this.mission.failed = true;
      for (const p of this.players) this.closeWindow(p);
      this.banner.setText('💀 Mission failed\n' + text).setVisible(true);
      return;
    }
    if (this.difficulty() <= 1) this.floatText(st, text, '#ff8a8a'); // на Easy/Normal — предупреждение
  }

  floatText(st, text, color = '#ffffff') {
    const c = proj((st.l + st.r) / 2, (st.t + st.b) / 2, (st.h || 0) + 30);
    const t = this.add.text(c.x, c.y, text, {
      color, fontSize: '13px', backgroundColor: '#0f1430dd', padding: { x: 6, y: 3 },
    }).setOrigin(0.5).setDepth(25000);
    this.tweens.add({ targets: t, y: c.y - 24, alpha: 0, delay: 900, duration: 500, onComplete: () => t.destroy() });
  }

  // Взять предмет прямо в руки (из окна станции)
  giveItem(pl, def) {
    const it = this.createItem(def, def.color, pl.body.x, pl.body.y);
    Object.assign(it, { type: def.type, code: def.code, ref: def.ref, calibrated: false, calRef: 20 + Math.floor(Math.random() * 70) });
    it.carrier = pl;
    pl.carrying = it;
    return it;
  }

  // Вернуть предмет на станцию-источник (держим его и «используем» станцию)
  returnItem(pl, st) {
    const it = pl.carrying;
    if (!it || !it.ref || it.ref.station !== st.id) return false;
    it.ref.stock = (it.ref.stock || 0) + 1;
    pl.carrying = null;
    it.gfx.destroy(); it.label.destroy();
    this.items = this.items.filter((x) => x !== it);
    this.floatText(st, `${it.code || ''} returned`, '#8be08b');
    return true;
  }

  // Взаимодействие со станцией. Только своего цвета (серые — общие).
  useStation(pl, st) {
    if (!this.canUse(pl, st)) {
      this.floatText(st, `${ROLES[st.role].name} only`, hex(ROLES[st.role].color));
      return;
    }
    if (pl.carrying && this.returnItem(pl, st)) return;
    if (st.user && st.user !== pl) { this.floatText(st, 'In use'); return; }
    if (st.kind === 'order') this.openBoard(pl, st);
    else this.openPanel(pl, st);
  }

  // ── Доска заказов ──────────────────────────────────────────────────────
  openBoard(pl, st) {
    const c = this.add.container(0, 0).setDepth(21000);
    const bg = this.add.graphics();
    const title = this.add.text(16, 10, 'Order board', { color: '#ffffff', fontSize: '17px', fontStyle: 'bold' });
    const sub = this.add.text(BOARD_W - 16, 14, '', { color: '#8c96c8', fontSize: '11px' }).setOrigin(1, 0);
    const rows = this.add.text(0, 0, '');
    c.add([bg, title, sub]);
    // текущий черновик: продолжаем с активного заказа, если он есть
    const o = this.order || { type: 0, target: 1, duration: 4, difficulty: 0 };
    const w = { kind: 'board', pl, st, c, bg, title, sub, sel: 0, draft: { ...o }, texts: [] };
    pl.win = w; st.user = pl;
    pl.body.body.setVelocity(0, 0);
    this.refreshBoard(w);
  }

  boardRows(w) {
    const d = w.draft;
    return [
      { key: 'type',       label: 'Mission type',   list: MISSION_TYPES, show: (v) => v.name },
      { key: 'target',     label: 'Target',       list: TARGETS,       show: (v) => v.name },
      { key: 'duration',   label: 'Duration'    , list: DURATIONS,     show: (v) => `${v} days` },
      { key: 'difficulty', label: 'Difficulty',    list: DIFFICULTIES,  show: (v) => v.name },
      { key: 'confirm',    label: this.order ? 'Update order' : 'Confirm order', button: true },
      { key: 'close',      label: 'Close', button: true },
    ].map((r) => ({ ...r, value: r.list ? r.list[d[r.key]] : null }));
  }

  // Проверка заказа на реалистичность: хватает ли длительности на перелёт
  boardCheck(d) {
    const type = MISSION_TYPES[d.type], target = TARGETS[d.target];
    const need = target.travel * (type.returnTrip ? 2 : 1) + 7; // + неделя на работу на месте
    if (DURATIONS[d.duration] < need) {
      return `Not enough time: transfer ≈ ${target.travel} days${type.returnTrip ? ' each way' : ''}, need ≥ ${need} days`;
    }
    return null;
  }

  boardInput(pl, pressed) {
    const w = pl.win, k = pl.keys, rows = this.boardRows(w);
    if (pressed(k.up)) w.sel = (w.sel + rows.length - 1) % rows.length;
    if (pressed(k.down)) w.sel = (w.sel + 1) % rows.length;
    const r = rows[w.sel];
    if (r.list) {
      const n = r.list.length;
      if (pressed(k.left)) w.draft[r.key] = (w.draft[r.key] + n - 1) % n;
      if (pressed(k.right) || pressed(k.use)) w.draft[r.key] = (w.draft[r.key] + 1) % n;
    } else if (pressed(k.use)) {
      if (r.key === 'close') { this.closeWindow(pl); return; }
      if (r.key === 'confirm') {
        const err = this.boardCheck(w.draft);
        if (err) { w.flash = err; }
        else {
          this.order = { ...w.draft };
          this.tickets = this.rollTickets(this.order);
          this.updateOrderHud();
          const t = MISSION_TYPES[this.order.type], g = TARGETS[this.order.target];
          this.floatText(w.st, `Order accepted: ${t.name} · ${g.name}`, '#8be08b');
          this.closeWindow(pl);
          return;
        }
      }
    }
    this.refreshBoard(w);
  }

  refreshBoard(w) {
    const rows = this.boardRows(w), d = w.draft, col = w.pl.cfg.color, use = w.pl.cfg.useName;
    for (const t of w.texts) t.destroy();
    w.texts = [];
    const add = (x, y, str, style, ox = 0) => {
      const t = this.add.text(x, y, str, { color: '#e6e9ff', fontSize: '13px', ...style }).setOrigin(ox, 0);
      w.c.add(t); w.texts.push(t); return t;
    };
    w.sub.setText(`opened by: ${ROLES[w.pl.role].name}`);
    let y = 40;
    const rowH = 30;
    // строки настроек (фон и подсветку рисует redrawBoardBg)
    rows.forEach((r, i) => {
      const sel = i === w.sel;
      if (r.button) {
        if (i === rows.length - 2) y += 6;
        const bw = r.key === 'close' ? 120 : 200;
        const bx = r.key === 'close' ? BOARD_W - 16 - bw : 16;
        if (r.key === 'close') y -= rowH; // кнопки в один ряд
        add(bx + bw / 2, y + 5, r.label, { fontStyle: 'bold' }, 0.5);
      } else {
        add(20, y + 4, r.label, { color: '#8c96c8' });
        add(BOARD_W - 24, y + 4, `‹  ${r.show(r.value)}  ›`, { fontStyle: sel ? 'bold' : 'normal' }, 1);
      }
      y += rowH;
    });
    // сводка заказа
    const type = MISSION_TYPES[d.type], target = TARGETS[d.target], diff = DIFFICULTIES[d.difficulty];
    y += 12;
    const err = this.boardCheck(d);
    const summary = [
      `${type.name}: ${type.desc.toLowerCase()}.`,
      `Target: ${target.name}   Δv ≈ ${target.dv} km/s   transfer ≈ ${target.travel} days`,
      `Mission cargo: ${type.cargo.join(', ')}`,
      '',
      `${diff.name}: ${diff.desc}`,
      `Max score: ${Math.round(BASE_SCORE * diff.mult)} pts  (×${diff.mult})`,
    ];
    const st = add(16, y, summary.join('\n'), { fontSize: '12px', lineSpacing: 4, wordWrap: { width: BOARD_W - 32 } });
    y += st.height + 6;
    if (err) {
      const t = add(16, y, '⚠ ' + err, { color: '#ffb35c', fontSize: '12px', wordWrap: { width: BOARD_W - 32 } });
      y += t.height + 6;
    } else if (w.flash) w.flash = null;
    const ft = add(16, y, `↑↓ — row   ←→ — value   ${use} — select`, { color: '#6f79ad', fontSize: '11px' });
    y += ft.height + 10;

    this.redrawBoardBg(w, rows, y, col);

    const c = proj((w.st.l + w.st.r) / 2, w.st.b, w.st.h);
    const pos = this.placeWindow(w.st, BOARD_W, y);
    w.c.setPosition(pos.x, pos.y);
  }

  // Фон доски и подсветка строк (отдельно, чтобы фон был под ними)
  redrawBoardBg(w, rows, totalH, col) {
    const g = w.bg;
    g.clear();
    g.fillStyle(0x0f1430, 0.97).fillRoundedRect(0, 0, BOARD_W, totalH, 10);
    g.lineStyle(2, 0x9aa3cf, 1).strokeRoundedRect(0, 0, BOARD_W, totalH, 10);
    let y = 40;
    const rowH = 30;
    rows.forEach((r, i) => {
      const sel = i === w.sel;
      if (r.button) {
        if (i === rows.length - 2) y += 6;
        const bw = r.key === 'close' ? 120 : 200;
        const bx = r.key === 'close' ? BOARD_W - 16 - bw : 16;
        if (r.key === 'close') y -= rowH;
        g.fillStyle(sel ? col : 0x2a3266, 1).fillRoundedRect(bx, y, bw, rowH - 4, 6);
      } else if (sel) {
        g.fillStyle(0x1d2550, 1).fillRoundedRect(10, y - 2, BOARD_W - 20, rowH - 2, 6);
        g.lineStyle(2, col, 1).strokeRoundedRect(10, y - 2, BOARD_W - 20, rowH - 2, 6);
      }
      y += rowH;
    });
    const sepY = y + 4;
    g.lineStyle(1, 0x3a4170, 1).lineBetween(16, sepY, BOARD_W - 16, sepY);
  }

  // Строка активного заказа в углу экрана
  updateOrderHud() {
    if (!this.orderHud) {
      this.orderHud = this.add.text(1264, 10, '', {
        color: '#8be08b', fontSize: '13px', align: 'right', backgroundColor: '#0f1430cc', padding: { x: 8, y: 4 },
      }).setOrigin(1, 0).setDepth(10000);
    }
    const o = this.order;
    this.orderHud.setText(`Order: ${MISSION_TYPES[o.type].name} · ${TARGETS[o.target].name} · ` +
      `${DURATIONS[o.duration]} days · ${DIFFICULTIES[o.difficulty].name}`);
  }

  // ── Окна станций ───────────────────────────────────────────────────────
  // Окно ложится поверх самой станции и «вытекает» наружу карты (вверх у верхней стены,
  // вниз у нижней, в стороны у боковых), чтобы не закрывать игровое поле другим игрокам.
  stationBox(st) {
    const r = st.hit || st, h = r.h !== undefined ? r.h : st.h;
    const pts = [];
    for (const [x, y] of [[r.l, r.t], [r.r, r.t], [r.r, r.b], [r.l, r.b]]) for (const z of [0, h || 0]) pts.push(proj(x, y, z));
    const xs = pts.map((p) => p.x), ys = pts.map((p) => p.y);
    return { l: Math.min(...xs), r: Math.max(...xs), t: Math.min(...ys), b: Math.max(...ys) };
  }

  placeWindow(st, w, h) {
    const bb = this.stationBox(st), r = st.hit || st;
    let x = (bb.l + bb.r) / 2 - w / 2, y = (bb.t + bb.b) / 2 - h / 2;
    if (r.t <= ty(1.5)) y = bb.b - h;            // у верхней стены — растём вверх
    else if (r.b >= ty(13.5)) y = bb.t;          // у нижней — вниз
    else if (r.l <= tx(3.5)) x = bb.r - w;       // у левой — влево
    else if (r.r >= tx(26.5)) x = bb.l;          // у правой — вправо
    return { x: Phaser.Math.Clamp(x, 4, 1276 - w), y: Phaser.Math.Clamp(y, 44, 716 - h) };
  }

  openPanel(pl, st) {
    const c = this.add.container(0, 0).setDepth(21000);
    const w = { kind: 'panel', pl, st, c, sel: 0, scroll: 0, sig: '' };
    pl.win = w; st.user = pl;
    pl.body.body.setVelocity(0, 0);
    this.refreshPanel(w);
  }

  closeWindow(pl) {
    if (!pl.win) return;
    if (pl.win.sticky) pl.win.sticky.destroy();
    pl.win.c.destroy();
    if (pl.win.st && pl.win.st.user === pl) pl.win.st.user = null;
    pl.win = null;
  }

  // Содержимое окна для каждой станции: заголовок, строки текста, выбираемые пункты, «стикер» с формулой
  panelSpec(w) {
    const st = w.st, pl = w.pl, diff = this.difficulty(), held = pl.carrying;
    const close = { label: 'Close', act: () => this.closeWindow(pl) };
    const ord = this.order;
    const spec = { title: st.name, info: [], rows: [], sticky: null, width: 180 };
    const takeRows = (list, type, color) => list.map((d) => ({
      label: `${d.name}`, right: (d.stock0 || 1) > 1 ? `${d.mass} kg ×${d.stock}` : `${d.mass} kg`,
      disabled: d.stock === 0,
      act: () => {
        if (pl.carrying) { this.floatText(st, 'Hands are full'); return; }
        if (d.stock === 0) { this.floatText(st, 'Out of stock'); return; }
        d.stock -= 1;
        this.giveItem(pl, { name: d.name, mass: d.mass, code: d.id, type, color, ref: d });
        this.closeWindow(pl);
      },
    }));

    switch (st.kind) {
      case 'catalog': { // Instrument Shelf — 32 прибора из каталога
        spec.width = 300;
        const req = new Set((this.tickets || []).flatMap((t) => t.needs));
        spec.rows = INSTRUMENTS.map((ins) => {
          const tag = diff === 0 && this.tickets ? (req.has(ins.id) ? '  ★' : '') : '';
          return {
            label: `${ins.id}  ${ins.name}${tag}`, right: ins.stock === 0 ? 'taken' : `${ins.mass}u ${ins.power}p`,
            color: diff === 0 ? CAT_COLORS[ins.cat] : null, disabled: ins.stock === 0,
            act: () => {
              if (pl.carrying) { this.floatText(st, 'Hands are full'); return; }
              if (ins.stock === 0) return;
              ins.stock = 0;
              this.giveItem(pl, { name: ins.name, mass: ins.mass * INSTRUMENT_KG, code: ins.id, type: 'instrument',
                color: 0xb98ae8, ref: Object.assign(ins, { station: 'shelf' }) });
              this.closeWindow(pl);
            },
            detail: ins,
          };
        });
        spec.rows.push(close);
        const d = spec.rows[Math.min(w.sel, spec.rows.length - 1)].detail;
        if (d) {
          spec.info = [`${d.id} — ${d.name}`, d.purpose, `Mass ${d.mass}u (${d.mass * INSTRUMENT_KG} kg) · power ${d.power}u · ${d.roles}`];
          if (this.tickets && diff <= 1) {
            const hits = this.tickets.filter((t) => t.needs.includes(d.id)).map((t) => t.id);
            spec.info.push(hits.length ? `Ticket: ${hits.join(', ')}` : 'Not requested by current tickets');
          }
          if (diff === 0) spec.info.push(`Category: ${d.cat}`);
        }
        spec.visibleRows = 6;
        break;
      }
      case 'calibrate': { // Analyzer — калибровка прибора в руках
        if (!held || held.type !== 'instrument') {
          spec.info = ['Bring an instrument case from the', 'Instrument Shelf to calibrate it.'];
        } else if (held.calibrated) {
          spec.info = [`${held.code} ${held.name}`, 'Calibrated ✓'];
        } else {
          w.reading = w.reading ?? 50;
          spec.info = [`${held.code} ${held.name}`, `Reference signal: ${held.calRef}`,
            diff <= 1 ? 'Match the reading to the reference.' : ''];
          spec.rows = [
            { label: `Reading: ${w.reading}`, right: '←→ ±1', adjust: (s) => { w.reading = Phaser.Math.Clamp(w.reading + s, 0, 99); } },
            { label: 'Coarse', right: '←→ ±10', adjust: (s) => { w.reading = Phaser.Math.Clamp(w.reading + s * 10, 0, 99); } },
            { label: 'Calibrate', act: () => {
              if (w.reading === held.calRef) { held.calibrated = true; this.floatText(st, `${held.code} calibrated ✓`, '#8be08b'); }
              else this.mistake(st, diff === 0 ? `Off by ${w.reading - held.calRef}` : 'Calibration failed');
            } },
          ];
        }
        spec.rows.push(close);
        break;
      }
      case 'science': { // Lab Console — научные тикеты заказа
        spec.width = 270;
        if (!this.tickets) spec.info = ['No order yet.', 'Place an order at the Order Screen.'];
        else {
          const used = new Set(this.packedInstruments().map((it) => it.code));
          const mass = [...used].reduce((a, id) => a + INSTRUMENT_BY_ID[id].mass, 0);
          spec.info = this.tickets.map((t) => `${this.ticketReady(t) ? '✓' : '•'} ${t.id} ${t.name}` +
            (diff <= 1 ? `  [${t.needs.join('+')}]` : ''));
          spec.info.push('', `Science payload: ${mass}/${SCIENCE_CAPACITY} u${mass > SCIENCE_CAPACITY ? '  ⚠ over capacity' : ''}`);
          const calib = this.packedInstruments().filter((it) => !it.calibrated).map((it) => it.code);
          if (calib.length && diff <= 1) spec.info.push(`Not calibrated: ${calib.join(', ')}`);
        }
        spec.rows = [close];
        break;
      }
      case 'tools': spec.rows = [...takeRows(TOOLS.map((t) => Object.assign(t, { stock: t.stock ?? 1, station: 'workbench' })), 'tool', 0xe57373), close]; spec.width = 220; spec.visibleRows = 5; break;
      case 'o2': case 'supply': case 'suits':
        spec.rows = [...takeRows(SUPPLIES[st.kind].map((s) => Object.assign(s, { station: st.id })), 'supply', 0x9ed36a), close]; break;
      case 'power': { // Fuel Cells — бюджет мощности упакованных приборов
        const list = this.packedInstruments();
        const total = list.reduce((a, it) => a + INSTRUMENT_BY_ID[it.code].power, 0);
        spec.info = list.length ? list.map((it) => `${it.code} — ${INSTRUMENT_BY_ID[it.code].power}u`) : ['No instruments in the cargo.'];
        spec.info.push('', diff <= 1 ? `Total ${total}/${POWER_BUDGET} u ${total > POWER_BUDGET ? '⚠ schedule them in turns' : '✓'}` : `Budget: ${POWER_BUDGET} u`);
        spec.rows = [close];
        break;
      }
      case 'scale': { // весы — Инженер видит, что в зоне
        const its = this.itemsOnScale();
        spec.width = 230;
        spec.info = its.length ? its.map((it) => `• ${it.code ? it.code + ' ' : ''}${it.name} — ${it.mass} kg`) : ['(no cargo in the zone)'];
        const crewOn = this.players.filter((p) => this.inScaleZone(p.body.x, p.body.y));
        if (crewOn.length) spec.info.push(`+ crew on the scale: ${crewOn.length}`);
        spec.info.push('', `Display: ${this.scaleReading().toFixed(1)} kg`);
        if (diff === 0) spec.info.push(`Cargo ${this.loadedMass()} kg + crew must be weighed too`);
        spec.rows = [close];
        break;
      }
      case 'planning': { // Mission Planning — цель и формула топлива
        const t = this.orderTarget();
        spec.width = 240;
        spec.info = ord ? [`${MISSION_TYPES[ord.type].name} → ${t.name}`, `Δv ≈ ${t.dv} km/s · transfer ≈ ${t.travel} days`] : ['No order yet (default: Mars).', `Δv ≈ ${t.dv} km/s`];
        if (diff === 0) {
          const m = this.launchMass();
          spec.info.push('', 'm_f = m · (e^(Δv / vₑ) − 1)', `m_f = m · (e^(${t.dv} / ${V_EXHAUST}) − 1)`,
            `m_f = m · ${this.fuelFactor().toFixed(3)}`, 'm = all cargo on the scale + every crew member');
        } else if (diff === 1) spec.sticky = ['m_f = m · (e^(Δv / vₑ) − 1)', `vₑ = ${V_EXHAUST} km/s`, 'm = cargo + crew'];
        spec.rows = [close];
        break;
      }
      case 'fuel': { // Fuel Port — ввод массы топлива
        w.digits = w.digits || [0, 0, 0, 0];
        const names = ['×1000', '×100', '×10', '×1'];
        spec.info = ['Enter fuel mass, kg:', `[ ${w.digits.join(' ')} ]`];
        spec.rows = w.digits.map((dgt, i) => ({ label: `Digit ${names[i]}: ${dgt}`, right: '←→',
          adjust: (s) => { w.digits[i] = (w.digits[i] + s + 10) % 10; } }));
        spec.rows.push({ label: 'Fill tank', act: () => {
          const v = Number(w.digits.join(''));
          if (v === this.requiredFuel()) { this.mission.fuelOk = true; this.mission.fuelValue = v; this.floatText(st, `Tank filled: ${v} kg ✓`, '#8be08b'); }
          else this.mistake(st, diff === 0 ? `${v} kg is wrong (check Mission Planning)` : 'Wrong fuel mass');
        } });
        if (this.mission.fuelOk) spec.info.push(`Filled: ${this.mission.fuelValue} kg ✓`);
        if (diff === 1) spec.sticky = ['m_f = m · (e^(Δv / vₑ) − 1)', 'm = cargo + crew'];
        spec.rows.push(close);
        break;
      }
      case 'engine': { // Launch Control
        const ready = this.tickets ? this.tickets.filter((t) => this.ticketReady(t)).length : 0;
        spec.info = [`Order: ${ord ? MISSION_TYPES[ord.type].name + ' → ' + this.orderTarget().name : '—'}`,
          `Science tickets ready: ${ready}/${this.tickets ? this.tickets.length : 0}`,
          `Fuel: ${this.mission.fuelOk ? this.mission.fuelValue + ' kg ✓' : 'not filled'}`];
        spec.rows = [{ label: '🚀 LAUNCH', disabled: !this.mission.fuelOk || !ord, act: () => {
          if (!ord) { this.floatText(st, 'No order'); return; }
          if (!this.mission.fuelOk) { this.mistake(st, 'Tank is empty'); return; }
          this.launch();
        } }, close];
        break;
      }
      default: spec.rows = [close];
    }
    return spec;
  }

  launch() {
    this.mission.launched = true;
    for (const p of this.players) this.closeWindow(p);
    const tk = this.tickets || [];
    const total = tk.reduce((a, t) => a + t.pts, 0) || 1;
    const got = tk.filter((t) => this.ticketReady(t)).reduce((a, t) => a + t.pts, 0);
    const mult = DIFFICULTIES[this.difficulty()].mult;
    const score = Math.max(0, Math.round(BASE_SCORE * mult * (got / total) - (this.mistakes || 0) * 50 * mult));
    this.banner.setText(`Launch!\nScience ${got}/${total} pts · mistakes ${this.mistakes || 0}\nScore: ${score} / ${Math.round(BASE_SCORE * mult)}`).setVisible(true);
  }

  panelInput(pl, pressed) {
    const w = pl.win, k = pl.keys, spec = w.spec;
    const rows = spec.rows;
    if (pressed(k.up)) w.sel = (w.sel + rows.length - 1) % rows.length;
    if (pressed(k.down)) w.sel = (w.sel + 1) % rows.length;
    const r = rows[Math.min(w.sel, rows.length - 1)];
    if (r && r.adjust) { if (pressed(k.left)) r.adjust(-1); if (pressed(k.right)) r.adjust(1); }
    if (pressed(k.use) && r) { if (r.act && !r.disabled) r.act(); else if (r.adjust) r.adjust(1); }
    if (pl.win === w) this.refreshPanel(w);
  }

  refreshPanel(w) {
    const spec = this.panelSpec(w);
    w.spec = spec;
    if (w.sel >= spec.rows.length) w.sel = spec.rows.length - 1;
    const vis = spec.visibleRows || spec.rows.length;
    if (w.sel < w.scroll) w.scroll = w.sel;
    if (w.sel >= w.scroll + vis) w.scroll = w.sel - vis + 1;
    const sig = JSON.stringify([spec.title, spec.info, spec.rows.map((r) => [r.label, r.right, r.disabled]), w.sel, w.scroll, spec.sticky]);
    if (sig === w.sig) return;
    w.sig = sig;
    w.c.removeAll(true);
    const bb0 = this.stationBox(w.st);
    const W = Math.round(Math.max(spec.width, Math.min(bb0.r - bb0.l, 320))), col = ROLES[w.st.role].color;
    const base = this.add.graphics(), bg = this.add.graphics(); // фон и подсветка строк (порядок в контейнере)
    w.c.add([base, bg]);
    let y = 8;
    const add = (x, yy, str, style = {}, ox = 0) => {
      const t = this.add.text(x, yy, str, { color: '#e6e9ff', fontSize: '11px', wordWrap: { width: W - 20 }, ...style }).setOrigin(ox, 0);
      w.c.add(t); return t;
    };
    add(10, y, spec.title, { color: hex(col), fontSize: '13px', fontStyle: 'bold' });
    y += 20;
    for (const line of spec.info) { const t = add(10, y, line || ' '); y += t.height + 1; }
    if (spec.info.length) y += 4;
    const rowH = 16;
    const shown = spec.rows.slice(w.scroll, w.scroll + vis);
    if (w.scroll > 0) { add(W - 12, y - 2, '▲', { color: '#8c96c8' }, 1); }
    shown.forEach((r, i) => {
      const idx = w.scroll + i, sel = idx === w.sel;
      if (sel) bg.fillStyle(0x1d2550, 1).fillRoundedRect(6, y - 1, W - 12, rowH, 4).lineStyle(1.5, col, 1).strokeRoundedRect(6, y - 1, W - 12, rowH, 4);
      if (r.color) bg.fillStyle(Phaser.Display.Color.HexStringToColor(r.color).color, 1).fillCircle(14, y + rowH / 2 - 1, 3);
      add(r.color ? 22 : 12, y + 1, r.label, { color: r.disabled ? '#5c6699' : '#e6e9ff', fontStyle: sel ? 'bold' : 'normal', wordWrap: null, fontSize: '10.5px' });
      if (r.right) add(W - 12, y + 1, r.right, { color: '#8c96c8', wordWrap: null, fontSize: '10.5px' }, 1);
      y += rowH;
    });
    if (w.scroll + vis < spec.rows.length) add(W - 12, y - 4, '▼', { color: '#8c96c8' }, 1);
    y += 4;
    const use = w.pl.cfg.useName;
    const ft = add(10, y, `↑↓ select · ←→ adjust · ${use} ok`, { color: '#6f79ad', fontSize: '10px' });
    y += ft.height + 8;
    base.fillStyle(0x0f1430, 0.96).fillRoundedRect(0, 0, W, y, 8);
    base.lineStyle(2, col, 1).strokeRoundedRect(0, 0, W, y, 8);
    const pos = this.placeWindow(w.st, W, y);
    w.c.setPosition(pos.x, pos.y);
    // «Стикер» с формулами (Normal) — рядом с окном
    if (w.sticky) { w.sticky.destroy(); w.sticky = null; }
    if (spec.sticky) {
      const s = this.add.container(0, 0).setDepth(21001);
      const tt = this.add.text(8, 6, spec.sticky.join('\n'), { color: '#4a3b00', fontSize: '11px', lineSpacing: 3 });
      const g = this.add.graphics();
      g.fillStyle(0xfff176, 1).fillRect(0, 0, tt.width + 16, tt.height + 12);
      g.fillStyle(0xf2c230, 1).fillRect(0, 0, tt.width + 16, 4);
      s.add([g, tt]);
      const sw = tt.width + 16;
      const sx = pos.x + W + 6 + sw < 1276 ? pos.x + W + 6 : pos.x - sw - 6;
      s.setPosition(sx, pos.y + 6).setAngle(-2);
      w.sticky = s;
    }
  }

  // ── Кадр ───────────────────────────────────────────────────────────────
  update(time, delta) {
    const dt = delta / 1000;
    const highlighted = new Set();
    this.hl.clear();
    for (const pl of this.players) {
      const t = this.updatePlayer(pl, dt);
      if (t && t.item) highlighted.add(t.item);
      if (t && t.station) {
        const st = t.station, R = st.hit || st, h = R.h !== undefined ? R.h : st.h;
        const top = [proj(R.l, R.t, h), proj(R.r, R.t, h), proj(R.r, R.b, h), proj(R.l, R.b, h)];
        this.hl.lineStyle(3, this.canUse(pl, st) ? 0xffffff : 0xff6b6b, 0.9).strokePoints(top, true);
      }
    }
    for (const it of this.items) this.drawItem(it, highlighted.has(it));
    this.updateScaleDisplay(dt);
    for (const pl of this.players) if (pl.win && pl.win.kind === 'panel') this.refreshPanel(pl.win); // данные живые
  }

  // Возвращает текущую цель героя { item?, station? } для подсветки
  updatePlayer(pl, dt) {
    const k = pl.keys;
    const down = (keys) => keys.some((key) => key.isDown);
    const pressed = (keys) => keys.some((key) => Phaser.Input.Keyboard.JustDown(key));

    let dx = down(k.right) - down(k.left);
    let dy = down(k.down) - down(k.up);
    if (pl.win || this.mission.launched || this.mission.failed) { dx = 0; dy = 0; } // пока открыто окно — стоим

    const vel = pl.body.body.velocity.clone();
    const moving = dx !== 0 || dy !== 0;
    pl.moving = moving;
    const target = new Phaser.Math.Vector2(dx, dy).normalize().scale(MAX_SPEED);
    const diff = target.clone().subtract(vel);
    const step = (moving ? ACCEL : FRICTION) * dt;
    if (diff.length() <= step) vel.copy(target);
    else vel.add(diff.setLength(step));
    pl.body.body.setVelocity(vel.x, vel.y);

    if (moving) {
      pl.facing = Phaser.Math.Angle.RotateTo(pl.facing, Math.atan2(dy, dx), TURN_SPEED * dt);
    }

    const p = pl.body;
    let tgt = null;
    if (pl.win && pl.win.kind === 'board') {
      this.boardInput(pl, pressed);
    } else if (pl.win) {
      this.panelInput(pl, pressed);
    } else if (!this.mission.launched && !this.mission.failed) {
      const item = pl.carrying ? null : this.targetItem(pl);
      const st = this.targetStation(pl);
      if (pl.carrying) {
        // с предметом в руках станция нужна только чтобы вернуть его на место или откалибровать
        const it = pl.carrying;
        const useful = st && this.canUse(pl, st) && (st.kind === 'calibrate' || (it.ref && it.ref.station === st.id));
        tgt = useful ? { station: st } : null;
      } else {
        // окно станции важнее предметов, лежащих на ней
        const stationFirst = st && this.canUse(pl, st);
        tgt = stationFirst ? { station: st } : item ? { item } : st ? { station: st } : null;
      }

      if (pressed(k.use)) {
        if (pl.carrying && tgt && tgt.station) {
          this.useStation(pl, tgt.station);
        } else if (pl.carrying) {
          // Кладём предмет перед собой: на низкую станцию под ним или на пол
          const it = pl.carrying;
          const under = this.solids.find((s) => !s.high &&
            it.x >= s.l && it.x <= s.r && it.y >= s.t && it.y <= s.b);
          it.support = under || null;
          it.z = under ? under.h : 0;
          it.vx = 0; it.vy = 0;
          it.carrier = null;
          pl.carrying = null;
        } else if (tgt && tgt.item) {
          pl.carrying = tgt.item;
          tgt.item.carrier = pl;
          tgt.item.support = null;
        } else if (tgt && tgt.station) {
          this.useStation(pl, tgt.station);
        }
      }
    }

    if (pl.carrying) {
      pl.carrying.x = p.x + Math.cos(pl.facing) * HOLD_DIST;
      pl.carrying.y = p.y + Math.sin(pl.facing) * HOLD_DIST;
      pl.carrying.rotation = pl.facing;
    }

    this.drawPlayer(pl, dt);

    // Конус обзора — на полу; белеет, когда есть с чем взаимодействовать
    const g = pl.cone;
    g.clear();
    const active = !!tgt;
    g.fillStyle(active ? 0xffffff : pl.cfg.color, active ? 0.22 : 0.13);
    g.lineStyle(1, pl.cfg.color, 0.5);
    const pts = [proj(p.x, p.y)];
    const N = 16;
    for (let i = 0; i <= N; i++) {
      const a = pl.facing - VIEW_ANGLE / 2 + (VIEW_ANGLE * i) / N;
      pts.push(proj(p.x + Math.cos(a) * VIEW_RANGE, p.y + Math.sin(a) * VIEW_RANGE));
    }
    g.fillPoints(pts, true);
    g.strokePoints(pts, true);
    return tgt;
  }

  // Герой: тень и кольцо цвета роли на полу + спрайт модели нужного направления и кадра
  drawPlayer(pl, dt) {
    const g = pl.gfx;
    const { x, y } = pl.body;
    const R = PLAYER_RADIUS;
    const floor = (r) => circlePts(x, y, r, 24).map((p) => proj(p.x, p.y, 0));
    g.clear();
    g.fillStyle(0x000000, 0.3).fillPoints(floor(R * 1.1), true);
    g.lineStyle(3, pl.cfg.color, 0.9).strokePoints(floor(R * 1.2), true);

    const step = (Math.PI * 2) / SPRITE.dirs;
    const dir = ((Math.round(pl.facing / step) % SPRITE.dirs) + SPRITE.dirs) % SPRITE.dirs;
    const v = pl.body.body.velocity;
    const speed = Math.hypot(v.x, v.y);
    let col;
    if (speed > 20) {
      pl.walkPhase = (pl.walkPhase + (dt * (speed / MAX_SPEED)) / SPRITE.walkTime) % 1;
      col = Math.floor(pl.walkPhase * SPRITE.walk);
    } else {
      pl.walkPhase = 0;
      col = SPRITE.walk;
    }
    const f = proj(x, y, 0);
    const p1 = proj(x + 10, y, 0);
    const k = (p1.x - f.x) / 10;
    pl.sprite
      .setFrame(dir * (SPRITE.walk + SPRITE.idle) * 2 + (pl.carrying ? SPRITE.walk + SPRITE.idle : 0) + col)
      .setPosition(f.x, f.y)
      .setScale((k * MODEL_UNIT) / SPRITE.pxPerUnit,
        ((k * MODEL_UNIT) / SPRITE.pxPerUnit) * (speed > 20 ? 1 : 1 + 0.025 * Math.sin(this.time.now / 400 + pl.cfg.x)))
      .setDepth(y);
  }
}
